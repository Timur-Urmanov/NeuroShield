from setuptools import setup, find_packages

setup(
    name="neuroshield",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.21.0",
        "torch>=1.9.0",
        "transformers>=4.20.0",
        "sentence-transformers>=2.2.0",
        "pydantic>=1.10.0",
    ],
    author="Timur Urmanov",
    description="Modular Cognitive Immune System for multilingual LLM environments",
    keywords=["AGI", "cognitive defense", "multi-agent", "immune system"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)